____________________________________________________________________
____________________________________________________________________
RRRRR   OOOOOO BBBBB  DDDDD  U    U RRRRR   BBBBB     /\    RRRRRR
R    R  |    | B    B D    D U    U R    R  B    B   /  \   R     R
R    R  |    | BBBBB  D    D U    U R    R  BBBBB   /    \  R     R
RRRRR   |    | B    B D    D U    U RRRRR   B    B -------- RRRRRR
R    R  |    | B    B D    D \    / R    R  B    B |      | R     R
R     R OOOOOO BBBBB  DDDDD   ----  R     R BBBBB  |      | R      R
____________________________________________________________________
____________________________________________________________________

A GDI Malware Made By:
Minhgotuknight19 (@minhtherain2.0) / LuK3 Archive (@minhtherain)
Date Create: 30/5/2025
Made In c++ and asm
_____________________________________________________________________
_____________________________________________________________________
EXPLANTION:
_____________________________________________________________________
_____________________________________________________________________

There Is No Safety, It's Destructive malware
do not try run pc, because they re destruction
your pc.