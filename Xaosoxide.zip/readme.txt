______________________________________________________________________________
______________________________________________________________________________
XX     XX     A    OOOOOOOOO  SSSSSSS OOOOOOOO XX     XX  II DDDDDDD  EEEEEEEE
 XX   XX     A A   O       O SS       O      O  XX   XX   II D      D E
  XX XX     A   A  O       O S        O      O   XX XX       D      D E
   XXX     A     A O       O  SSSSSSS O      O    XXX     II D      D EEEEEEEE
  XX XX    AAAAAAA O       O       SS O      O   XX XX    II D      D E
 XX   XX   A     A O       O        S O      O  XX   XX   II D      D E
XX     XX  A     A OOOOOOOOO SSSSSSS  OOOOOOOO XX     XX  II DDDDDDD  EEEEEEEE
______________________________________________________________________________
______________________________________________________________________________
A GDI Malware Made By:
Minhgotuknight19 (@minhtherain2.0) / LuK3 Archive (@minhtherain)
Date Create:June 7 2025
Made In c++ and asm
_____________________________________________________________________
_____________________________________________________________________
EXPLANTION:
_____________________________________________________________________
_____________________________________________________________________

There Is No Safety,
It's Destructive malware
do not try run pc,
because they re destruction
your pc.

SAFETY:
THEY'RE RUN SAFE ON REAL PC



















Hi Pawin Vechanon, Marlon2210 and more