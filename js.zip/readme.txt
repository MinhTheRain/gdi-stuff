js.exe

made by minhgotuknight19 / luk3 archive
my new malware

credit to n17pro3426 for this effect
credit to nywal for swirl