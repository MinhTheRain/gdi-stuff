N    N U    U K   K EEEEE
NN   N U    U K  K  E
N N  N U    U KKK   EEEEE
N  N N U    U K  K  E
N   NN  UUUU  K   K EEEEE XP . EXE

My New Malware!
Created By Minhgotuknight19 / LuK3 Archive
Inspiried By Sigma





































Hi I am Wynn (Pawin Vechanon), Yedb0y33k (flinkez), Marlon2210 (blue Boi) and more..........