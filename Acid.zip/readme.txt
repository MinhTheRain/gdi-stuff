---------------------
   ^    {{{{ * ))))
  ^ ^  {       )   )
 ^   ^ {     | )   )
 ^^^^^ {     | )   )
 ^   ^  {{{{ | ))))
---------------------

A GDI Malware
Made By Minhgotuknight19/LuK3 Archive
____________________
LuK3 Archive:
@minhtherain
Minhgotuknight19:
@minhtherain2.0
____________________

hi Pawin Vechanon, Marlon2210 and more user malware test....................................................................................................................................................................................

There Is No Safety, Only Destruction