Xultorula.exe
Made By Minhgotuknight19 / LuK3 Archive
type - trojan

credit to ArcTicZera and WiPet For HSL
credit to EthernalVortex For PRGBQUAD







































hi I am Wynn, b9tinu, Marlon2210