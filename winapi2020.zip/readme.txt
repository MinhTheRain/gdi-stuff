winapi2020.exe
by Minhgotuknight19 / LuK3 Archive
My New Malware
Credits To ArcTicZera for the HSL and RGBQUAD
Credits To EthernalVortex for PRGBQUAD
Credits To N17pro3426 and pankoza for some payload






































hi Pawin Vechanon, Flinkez, Blue Boi and more.....................................