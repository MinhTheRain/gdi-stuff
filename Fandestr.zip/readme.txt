______________________________________________________________________________
______________________________________________________________________________
FFFFFF   AA    NN       NN  DDDDDDD  EEEEEEEE   SSSSSSSS TTTTTTT  RRRRRRR
F       A  A   NNN      NN  D      D E         SS           T     R      R
F      A    A  NN NN    NN  D      D E         SS           T     R      R
FFFFF  AAAAAA  NN  NN   NN  D      D EEEEEEEE   SSSSSSSS    T     RRRRRRR
F      A    A  NN   NN  NN  D      D E                 SS   T     R      R
F      A    A  NN     NNNN  D      D E                 SS   T     R       R
F      A    A  NN       NN  DDDDDDD  EEEEEEEE   SSSSSSSS    T     R        R
______________________________________________________________________________
______________________________________________________________________________
A GDI Malware Made By:
The Squirrel Conspiracy (@minhtherain2.0) / LuK3 Archive (@minhtherain)
Date Create:June 24 2025
Made In c++ and asm
_____________________________________________________________________
_____________________________________________________________________
EXPLANTION:
_____________________________________________________________________
_____________________________________________________________________

There Is No Safety,
It's Destructive malware
do not try run pc,
because they re destruction
your pc.

you need to run x64, run x86 is error not a valid win32




















Hi Pawin Vechanon, Marlon2210 and more