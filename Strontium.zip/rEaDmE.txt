Strontium.exe

Made By Minhgotuknight19 / Luk3 Archive

Credits To ArcTicZera and WiPet For HSL
Credits To EthernalVortex For PRGBQUAD
Credits To N17Pro3426 and pankoza for some payload
























hello I am Wynn, yedb0y33k (b9tinu), Marlon2210 and more.............................

  **  **
  **  **
  **  **
*        *
 ********