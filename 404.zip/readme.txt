    4 ooooooo     4
  4 4 oo    o   4 4
 4  4 o o   o  4  4
44444 o  o  o 44444
    4 o   o o     4
    4 ooooooo     4 . exe

By Minhgotuknight19 / LuK3 Archive

Credits to ArcTicZera and WiPet For The HSL
Credits To EthernalVortex For PRGBQUAD Shader
Credits to N17pro3426 and pankoza for some payload and shader
created date in December 1 2024
type in trojan



























hi I am Wynn, B9tinu (yedb0y33k), Marlon2210 and more........