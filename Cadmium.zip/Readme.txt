Cadmium.exe

Malware Name: Cadmium
Made By Minhgotuknight19 / LuK3 Archive
Type: Danger
Made In: C++ and ASM
Made With: Visual Studio 2017
Work best in: Windows XP - 11


Hi I am Wynn, Flinkez, Blue Boi and more...
enjoy....

  #   #
  #   #
  #   #
#       #
 #######
