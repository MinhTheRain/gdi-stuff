golaris.exe

by Minhgotuknight19 / LuK3 Archive
made in c++
Credit to ArcTicZera and Wipet for HSL
Credit to EthernalVortex for PRGBQUAD
Credit to N17Pro3426 for Some payload




























hello I am Wynn, yedb0y33k, Marlon2210