INALL.exe

By Minhgotuknight19 / LuK3 Archive

My New Malware

Credits To JhoPro/ArcTicZera and wipet for HSL
Credits To EthernalVortex/VortexGTX For PRGBQUAD
Credits To N17Pro3426 and pankoza for some payload





























hi I am Wynn, Yedb0y33k/b9tinu/Flinkez, Blue Boi/Marlon2210 and more.......................