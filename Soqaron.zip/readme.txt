 SSSS
S
 SSSS
     S
 SSSS  O Q A R O N . EXE
My New Malware
Made By Minhgotuknight19/LuK3 Archive
Work Best In Windows XP - 11
Credits To N17Pro3426, pankoza, I am Wynn (Pawin Vechanon) For The Fake BSOD and Some Payload
Type: Damage
Made In: c++

Hi Pawin Vechanon (I am Wynn), Flinkez (yedb0y033k), Blue Boi (Marlon2210) And More........................
...........................................................................................................
............................................................................................................

      *
       *
 ****  *
       *
 ****  *
       *
      *