BBBBB
B    B
BBBBB
B    B
BBBBB  L O O D E S.exe

My New Most Malware

Credits to ArcTicZera For The HSL, RGBQUAD and HSV
Credits To N17Pro3426 for the 3D cUbe Draw
Credits To nywal For PRGBTRIPLE
Credits To EthernalVortex For PRGBQUAD

Made By: Minhgotuknight19 / LuK3 Archive
Type: Damage
Made In: C++





















Hi I am Wynn, Flinkez (yedb0y33k), Blue Boi (marlon2210) and more.....................................................................................................