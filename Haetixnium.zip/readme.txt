____________________________________________________________________________
|      |    ^    EEEEEEE TTTTTT  i  x    x  nn    nn   i    u    u  mmmmmmm
|      |   ^ ^   E         TT        x  x   nnn   nn        u    u  m  m   m
--------  ^^^^^  EEEEEEE   TT    i    xx    nn nn nn   i    u    u  m  m   m
|      |  ^   ^  E         TT    i   x  x   nn   nnn   i    u    u  m  m   m
|      |  ^   ^  EEEEEEE   TT    i  x    x  nn    nn   i     uuuuu  m  m   m
____________________________________________________________________________
                                                                             
made by Minhgotuknight19 (@minhtherain2.0) / LuK3 Archive (@minhtherain)
a gdi trojan made in c++
exec's:
_______________________
Haetixnium.exe
Haetixnium.peaceful.exe
_______________________

WARNING!
DO NOT RAN YOUR COMPUTER!
