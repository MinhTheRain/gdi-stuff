     44 666666   eeeeee x    x eeeee
    4 4 6        e       x  x  e
   4  4 6        e        xx   eeeee
  4   4 666666   e       x  x  e
 444444 6    6   eeeeee x    x eeeee
      4 6    6   e
      4 6    6   e
      4 666666 . eeeeee

my new malware
made by Minhgotuknight19 / LuK3 Archive
Credits To JhoPro/ArcTicZera For The HSL, HSV and RGBQUAD
Credits To nywal For The PRGBTRIPLE, But I Convert To LPRGBTRIPLE and NPRGBTRIPLE
Credits To EthernalVortex For The PRGBQUAD, But I Convert To LPRGBQUAD
Created Date: jan 2 2025 - jan 3 2025
made in c++ and ASM

Hi I am Wynn (Pawin Vechanon), yedb0y33k (flinkez),  Marlon2210 (blue boi) and more............................

:)