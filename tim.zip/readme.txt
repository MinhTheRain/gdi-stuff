TTTTTT II MM     MM  EEEEEE X   X EEEEEE
  TT      MM MMM MM  E       X X  E
  TT   II M MM MM M  EEEEEE   X   EEEEEE
  TT   II M       M .E       X X  E
                     EEEEEE X   X EEEEEE
Made By Minhgotuknight19 / LuK3 Archive
Credits To JhoPro/ArcTicZera for HSL
Credits To EthernalVortex For PRGBQUAD
Credits To N17Pro3426 and pankoza for some payload
Made in c++
type: Damage
works best in: Windows XP - 11
Creation Date: december 27 2024 - december 28 2024




































hi I am Wynn (Pawin Vechanon), yedb0y33k (flinkez), Marlon2210 (Blue Boi) and More.................................................
