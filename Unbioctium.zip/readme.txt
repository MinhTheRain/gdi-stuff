______________________________________________________________________________
______________________________________________________________________________
UU   UU NN    NN BBBBBB   II  OOOOOOO  CCCCCCC  TTTTTTT  II UU   UU  MMMMMMM
UU   UU N NN  NN B     B      O     O  CC         TTT       UU   UU  M  M  M
UU   UU N  NN NN BBBBBB   II  O     O  CC          T     II UU   UU  M  M  M
UU   UU N   N NN B     B  II  O     O  CC          T     II UU   UU  M  M  M
 UUUUU  N    NNN BBBBBB   II  OOOOOOO  CCCCCCC     T     II  UUUUU   M  M  M
______________________________________________________________________________
______________________________________________________________________________
A GDI Malware Made By:
The Squirrel Conspiracy (@minhtherain2.0) / LuK3 Archive (@minhtherain)
Date Create:June 18 2025
Made In c++ and asm
_____________________________________________________________________
_____________________________________________________________________
EXPLANTION:
_____________________________________________________________________
_____________________________________________________________________

There Is No Safety,
It's Destructive malware
do not try run pc,
because they re destruction
your pc.

you need to run x64, run x86 is error not a valid win32




















Hi Pawin Vechanon, Marlon2210 and more