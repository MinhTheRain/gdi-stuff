TTTTT  OOOOO  N  N I  CCCCC   EEEEEE X  X EEEEEE
  T   O     O NN N   C        E_____  XX  E_____
  T   O     O N NN I C        E       XX  E
  T    OOOOO  N  N I  CCCCC . EEEEEE X  X EEEEEE
A modified and inspired by Dominik's Holzer
By Minhgotuknight9 / LuK3 Archive
Made In C++ and ASM
Works Best In Windows Vista - 11






















Hi I am Wynn, Flinkez, Blue Boi
