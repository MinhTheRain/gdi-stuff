temysium.exe

made by Minhgotuknight19 / LuK3 archive

Credit to ArcTicZera and WiPet for HSL
Credit To EthernalVortex For PRGBQUAD
Credit To N17Pro3426

Ratyu MBR




























Hi I am Wynn, yedb0y33k (b9tinu), Marlon2210