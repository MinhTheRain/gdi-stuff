PPP
P  P  OOOOO  L      L       U    U N    N
PPP  O     O L      L       U    U NN   N
P    O     O L      L       U    U N NN N
P    O     O L      L       UU  UU N  NNN
P     OOOOO  LLLLLL LLLLLLL  UUUU  N    N

Made By Minhgotuknight19 / LuK3 Archive
This Is New Malware!
Creation Date: 1-2-2025 to 3-2-2025
Type: Damage
Puibclity: Puibc (See In Malware Test)

Malware Test
Pawin Vechanon a.k.a I am Wynn, TheRealYB a.k.a Flinkez a.k.a yedb0y33k, Marlon2210 and more.................................................................................................................................................................................................
01010011001010101018465738692840763890461890184
43308291742076438916582913462843812